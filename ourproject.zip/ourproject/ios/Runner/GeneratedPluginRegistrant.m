//
//  Generated file. Do not edit.
//

#import "GeneratedPluginRegistrant.h"

#if __has_include(<animated_qr_code_scanner/AnimatedQrCodeScannerPlugin.h>)
#import <animated_qr_code_scanner/AnimatedQrCodeScannerPlugin.h>
#else
@import animated_qr_code_scanner;
#endif

#if __has_include(<qr_code_scanner/FlutterQrPlugin.h>)
#import <qr_code_scanner/FlutterQrPlugin.h>
#else
@import qr_code_scanner;
#endif

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [AnimatedQrCodeScannerPlugin registerWithRegistrar:[registry registrarForPlugin:@"AnimatedQrCodeScannerPlugin"]];
  [FlutterQrPlugin registerWithRegistrar:[registry registrarForPlugin:@"FlutterQrPlugin"]];
}

@end
